DynamicPageList
=================================

DynamicPageList is a MediaWiki extension which allows wiki users to create a list of pages that are listed in a set of categories.

Complete documentation is available on [the extension page on mediawiki.org](https://www.mediawiki.org/wiki/Extension:DynamicPageList_%28Wikimedia%29).
